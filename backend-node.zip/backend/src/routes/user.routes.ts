import { Router } from "express";
import { authenticateToken } from "../middlewares/auth.middleware";
import { UserService } from "../services/user.service";

const router = Router();
const userService = new UserService();

router.get("/", authenticateToken, userService.getAll);

router.get("/:id", authenticateToken, userService.getById);

router.put("/:id", authenticateToken, userService.update);

router.delete("/:id", authenticateToken, userService.delete);

export default router;
