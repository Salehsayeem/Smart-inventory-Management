import { Router } from "express";
import { AuthController } from "../modules/auth/auth.controller";
import { authenticateToken } from "../middlewares/auth.middleware";

const router = Router();


router.post("/register", AuthController.register);
router.post("/login", AuthController.login);

router.get('/protected', authenticateToken, (req, res) => {
    res.json({ message: `Hello user!`, user: req.user });
  });
  
  // Public route
  router.get('/public', (req, res) => {
    res.json({ message: 'Anyone can access this' });
  });
export default router;
