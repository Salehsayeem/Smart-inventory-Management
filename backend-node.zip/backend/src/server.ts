import { app } from './app';
import { prisma } from './prisma/client';
const port = process.env.PORT || 1111;

async function bootstrap() {
  try {
    await prisma.$connect();
    console.log('Database connected');
    
    app.listen(port, () => {
      console.log(`Server running on http://localhost:${port}`);
    });
  } catch (error) {
    console.error('Database connection failed', error);
    process.exit(1);
  }
}

bootstrap();
