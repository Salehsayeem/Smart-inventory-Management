export const apiResponse = (succeed: boolean, message: string, data: any = null) => {
    return { succeed, message, data };
  };
  