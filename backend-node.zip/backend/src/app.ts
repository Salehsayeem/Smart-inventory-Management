import express from 'express';

import helmet from 'helmet';
import 'express-async-errors'; // to handle async errors without try-catch
import cors from 'cors';
import authRouter from './routes/auth.routes';
import { errorMiddleware } from "./middlewares/error.middleware";
const app = express();

// Middlewares
app.use(helmet());
app.use(cors());
app.use(express.json());

// Routes

app.use('/api/auth', authRouter);


// Global Error Handler
app.use(errorMiddleware);


export { app };

// npx prisma migrate dev --name init --schema=./src/prisma/schema.prisma
// npx prisma generate --schema=./src/prisma/schema.prisma
//npm run prisma:generate
