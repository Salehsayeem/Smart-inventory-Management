import { prisma } from "../prisma/client";
import { Request, Response } from "express";

export class UserService {
  async getAll(req: Request, res: Response) {
    const users = await prisma.user.findMany();
    res.json(users);
  }

  async getById(req: Request, res: Response) {
    const { id } = req.params;
    const user = await prisma.user.findUnique({ where: { id } });
    res.json(user);
  }

  async update(req: Request, res: Response) {
    const { id } = req.params;
    const { full_name, email } = req.body;

    const updatedUser = await prisma.user.update({
      where: { id },
      data: { full_name, email },
    });

    res.json(updatedUser);
  }

  async delete(req: Request, res: Response) {
    const { id } = req.params;

    await prisma.user.delete({ where: { id } });

    res.json({ message: "User deleted" });
  }
}
