import { prisma } from "../prisma/client";
import bcrypt from "bcryptjs";
import { generateToken } from "../utils/jwt.util";
import RegisterRequest from "../interfaces/auth.dto";
import LoginRequest from "../interfaces/auth.dto";


export class AuthService {
  static async register(data: RegisterRequest) {
    const { shop_name, full_name, email, password } = data;

    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) {
      throw { statusCode: 400, message: "Email already exists" };
    }

    const shop = await prisma.shop.create({
      data: {
        name: shop_name,
      },
    });

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: {
        shop_id: shop.id,
        full_name,
        email,
        password_hash: hashedPassword,
      },
    });

    return { id: user.id, email: user.email, fullName: user.full_name, shopId: shop.id };

  }

  static async login(data: LoginRequest) {
    const { email, password } = data;

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || user.is_active) {
      throw { statusCode: 400, message: "Invalid credentials" };
    }

    const isPasswordValid = await bcrypt.compare(password, user.password_hash);
    if (!isPasswordValid) {
      throw { statusCode: 400, message: "Invalid credentials" };
    }

    const token = generateToken({ id: user.id, tenantId: user.shop_id, role: user.role });

    return token;
  }
}
