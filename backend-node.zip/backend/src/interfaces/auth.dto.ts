import { JwtPayload } from "jsonwebtoken";

export default interface RegisterRequest {
  shop_name: string;
  full_name: string;
  email: string;
  password: string;
}

export default interface LoginRequest {
  email: string;
  password: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: string | JwtPayload;
    }
  }
}
