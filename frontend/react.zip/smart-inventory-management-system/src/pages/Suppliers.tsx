import React from 'react';
import './Suppliers.css';

const Suppliers: React.FC = () => {
  return (
    <div className="page-content">
      <h2>Suppliers</h2>
      <div className="suppliers-container">
        {/* Suppliers management content will be added here */}
      </div>
    </div>
  );
};

export default Suppliers; 