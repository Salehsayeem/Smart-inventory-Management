import React, { useEffect, useState } from "react";
import "./ProductList.css";
import GenericModal from "../components/modal/Modal";
import CustomFormComponent, {
  FormInputConfig,
} from "../components/customFormComponent/CustomFormComponent";
import { CommonDdlResponse, ProductLandingDataDto } from "../types";
import { CategoriesOfShopDdl, getProductsByShopId } from "../api/apiService";

const Product: React.FC = () => {
  const [products, setProducts] = useState<ProductLandingDataDto[]>([]);
   const [categories, setCategories] = useState<CommonDdlResponse[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<string | null>(null);
  // const [form, setForm] = useState<CreateProductRequest>({
  //   name: "",
  //   description: "",
  //   price: 0,
  //   stock: 0,
  //   categoryId: 0,
  // });
  // const [editingProduct, setEditingProduct] = useState<ProductType | null>(null);

  useEffect(() => {
    fetchProducts();
    fetchProductCategories();
  }, []);

  const fetchProducts = async () => {
    try {
      const data = await getProductsByShopId();
      if (Array.isArray(data)) {
        setProducts(data);
      } else {
        setProducts([]);
      }
    } catch (error) {
      console.error("Error fetching products:", error);
      setProducts([]);
    }
  };

  const fetchProductCategories = async (search: string) => {
    try {
      const response = await CategoriesOfShopDdl(search);
      setCategories(Array.isArray(response?.data) ? response.data : []);
    } catch (error) {
      console.error("Error fetching product categories:", error);
    }
  };

  // const handleInputChange =
  //   (field: keyof CreateProductRequest) =>
  //     (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
  //       setForm({
  //         ...form,
  //         [field]:
  //           field === "price" || field === "stock" || field === "categoryId"
  //             ? Number(e.target.value)
  //             : e.target.value,
  //       });
  //     };

  // const handleOpenModal = (product?: ProductType) => {
  //   if (product) {
  //     setEditingProduct(product);
  //     setForm({
  //       name: product.name,
  //       description: product.description,
  //       price: product.price,
  //       stock: product.stock,
  //       categoryId: product.categoryId,
  //     });
  //   } else {
  //     setEditingProduct(null);
  //     setForm({
  //       name: "",
  //       description: "",
  //       price: 0,
  //       stock: 0,
  //       categoryId: 0,
  //     });
  //   }
  //   setIsModalOpen(true);
  // };

  // const handleSaveProduct = async (e: React.FormEvent) => {
  //   e.preventDefault();
  //   try {
  //     if (editingProduct) {
  //       await updateProduct(editingProduct.id, form);
  //     } else {
  //       await createProduct(form);
  //     }
  //     setIsModalOpen(false);
  //     fetchProducts();
  //   } catch (error) {
  //     console.error("Error saving product:", error);
  //   }
  // };

  // const productInputs: FormInputConfig[] = [
  //   {
  //     id: "name",
  //     label: "Product Name",
  //     type: "text",
  //     value: form.name,
  //     required: true,
  //     placeholder: "Enter product name",
  //     onChange: handleInputChange("name"),
  //   },
  //   {
  //     id: "description",
  //     label: "Description",
  //     type: "textarea",
  //     value: form.description,
  //     required: false,
  //     placeholder: "Enter product description",
  //     onChange: handleInputChange("description"),
  //   },
  //   {
  //     id: "price",
  //     label: "Price",
  //     type: "number",
  //     value: String(form.price),
  //     required: true,
  //     placeholder: "Enter price",
  //     onChange: handleInputChange("price"),
  //   },
  //   {
  //     id: "stock",
  //     label: "Stock",
  //     type: "number",
  //     value: String(form.stock),
  //     required: true,
  //     placeholder: "Enter stock quantity",
  //     onChange: handleInputChange("stock"),
  //   },
  //   {
  //     id: "categoryId",
  //     label: "Category",
  //     type: "select",
  //     value: String(form.categoryId),
  //     required: true,
  //     options: categories.map((c) => ({ value: String(c.key), label: c.value })),
  //     onChange: handleInputChange("categoryId"),
  //   },
  // ];

  return (
    <div className="product-container">
      <h1>Product List</h1>
      <div className="product-card">
        <div className="product-card-header">
          {/* <button className="product-add-btn" onClick={() => handleOpenModal()}>
            + New Product
          </button> */}
        </div>
        <div className="product-table-responsive">
          <table className="product-table">
            <thead>
              <tr>
                <th>SL</th>
                <th>Name</th>
                <th>Description</th>
                <th>SKU</th>
                <th>Unit Price</th>
                <th>Category</th>
                {/* <th>Action</th> */}
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id}>
                  <td>{p.sl}</td>
                  <td>{p.name}</td>
                  <td>{p.description}</td>
                  <td>{p.sku}</td>
                  <td>{p.unitPrice}</td>
                  <td>{p.categoryName}</td>
                  <td>
                    {/* <button
                      className="product-edit-btn"
                      title="Edit"
                      onClick={() => handleOpenModal(p)}
                      style={{ marginRight: "8px" }}
                    >
                      <i className="bx bx-edit"></i>
                    </button> */}
                    |
                    {/* <button
                      className="product-delete-btn"
                      title="Delete"
                      onClick={() => {
                        setProductToDelete(p.id);
                        setIsDeleteModalOpen(true);
                      }}
                      style={{ marginLeft: "8px" }}
                    >
                      <i className="bx bx-trash"></i>
                    </button> */}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* <GenericModal
        show={isModalOpen}
        title={editingProduct ? "Edit Product" : "Add Product"}
        onClose={() => setIsModalOpen(false)}
      >
        <CustomFormComponent
          inputs={productInputs}
          onSubmit={handleSaveProduct}
          onCancel={() => setIsModalOpen(false)}
          submitLabel="Save"
          cancelLabel="Cancel"
        />
      </GenericModal>

      <GenericModal
        show={isDeleteModalOpen}
        title="Confirm Delete"
        onClose={() => setIsDeleteModalOpen(false)}
      >
        <div>
          <p>Are you sure you want to delete this product?</p>
          <div className="d-flex justify-content-end">
            <button
              className="btn btn-secondary me-2"
              onClick={() => setIsDeleteModalOpen(false)}
            >
              Cancel
            </button>
            <button
              className="btn btn-danger"
              onClick={async () => {
                if (productToDelete) {
                  try {
                    await deleteProduct(productToDelete);
                    setIsDeleteModalOpen(false);
                    setProductToDelete(null);
                    fetchProducts();
                  } catch (error) {
                    console.error("Error deleting product:", error);
                    setIsDeleteModalOpen(false);
                    setProductToDelete(null);
                  }
                }
              }}
            >
              Delete
            </button>
          </div>
        </div>
      </GenericModal> */}
    </div>
  );
};

export default Product;
