import React, { useState, useEffect } from "react";

interface Option {
  value: string | number;
  label: string;
}

interface SearchableSelectProps {
  id: string;
  label: string;
  value: string | number;
  options: Option[];
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  onSearch: (search: string) => void;
  required?: boolean;
  placeholder?: string;
}

const SearchableSelect: React.FC<SearchableSelectProps> = ({
  id,
  label,
  value,
  options,
  onChange,
  onSearch,
  required,
  placeholder = "Select...",
}) => {
  const [search, setSearch] = useState("");

  useEffect(() => {
    onSearch(search);
    // eslint-disable-next-line
  }, [search]);

  return (
    <div className="mb-3">
      <label htmlFor={id} className="form-label">{label}</label>
      <input
        type="text"
        className="form-control mb-2"
        placeholder={`Search ${label.toLowerCase()}...`}
        value={search}
        onChange={e => setSearch(e.target.value)}
      />
      <select
        id={id}
        className="form-select"
        value={value}
        onChange={onChange}
        required={required}
      >
        <option value="">{placeholder}</option>
        {options.map(opt => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default SearchableSelect;